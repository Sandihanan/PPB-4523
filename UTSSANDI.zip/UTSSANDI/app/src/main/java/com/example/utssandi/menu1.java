package com.example.utssandi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class menu1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);
    }
}